import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import java.awt.event.KeyEvent; 
import java.awt.event.KeyListener; 

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;

public class GraveDigger
{
  private boolean hasArmor;
  private boolean hasPotion;
  private boolean movingRight = false;
  private boolean movingLeft = false;
  private boolean movingUp = false;
  private boolean movingDown = false;
  private boolean movingRightFinish = false;
  private boolean movingLeftFinish = false;
  private boolean movingUpFinish = false;
  private boolean movingDownFinish = false;
  private int x;
  private int y;
  private int xa;
  private int ya;
  private int xL;
  private int yL;
  private int height = 32; 
  private int width = 32;
  private Game game;
  private Level level;
  private boolean isDead = false;
  private boolean hasKey = false;
  private int coins;
  private int potionCounter = 0;
  private boolean potionOn = false;
  
  
  public GraveDigger(boolean hasArmor, boolean hasPotion,int x, int y, int xa, int ya, Game game, Level level, int coins)
  {
    this.hasArmor = hasArmor;  
    this.hasPotion = hasPotion;
    
    this.x = x;
    this.y = y;
    this.xa = xa;
    this.ya = ya;
    
    this.game = game;
    this.level = level;
    this.coins=coins;
  }
  public int getPlayerX(){
    return x;
  }
  
  public int getPlayerY() {
    return y;
  }
  
  
  
  public void move(){
    //Long complicated move method for the GraveDigger
    
    
    //The following if statements set the "moving___" variables
    if ((x + xa <0) || (x + xa > (1280 - width) )){
      xa *= 0;
      movingLeft = false;
      movingRight=false;
    }
    if ((y + ya <64) || (y + ya > (960) )){
      ya *= 0;
      movingUp=false;
      movingRight=false;
    }
    
    xL = ((x + xa + 32)/32);
    if(movingLeft)
      xL++;
    yL =((y + ya - 32)/32);
    if(movingUp)
      yL++;
    
    if(movingUp && (level.getTile(xL, yL-1)== 'r')){
      xa = 0;
      ya = 0;
      movingUp = false;
      movingDownFinish =true;
    }
    else if(movingDown && (level.getTile(xL, yL+1)== 'r')){
      xa = 0;
      ya = 0;
      movingDown = false;
      movingUpFinish=true;
    }
    else if(movingRight && (level.getTile(xL+1, yL)== 'r')){
      xa = 0;
      ya = 0;
      movingRight = false;
      movingLeftFinish=true;
    }
    else if(movingLeft && (level.getTile(xL-1, yL)== 'r')){
      xa = 0;
      ya = 0;
      movingLeft = false;
      movingRightFinish=true;
    }
    
    else{
      if(level.getTile(xL,yL)=='d'||level.getTile(xL,yL)=='g')
        level.setTile(xL,yL,'t');                    
    }
    
    if((x%32 != 0) || (y)%32 !=0){
      if(movingLeftFinish){
        xa = -1;
        ya = 0;
      }
      if(movingRightFinish){
        xa = 1;
        ya = 0;
      }
      if(movingUpFinish){
        ya = -1;
        xa = 0;
      }
      if(movingDownFinish){
        ya = 1;
        xa = 0;
      }
    }
    
    else if((x%32 == 0) || (y)%32 ==0){
      if(movingLeftFinish){
        movingLeftFinish = false;
        movingLeft=false;
        xa = 0;
        ya = 0;
      }
      if(movingRightFinish){
        movingRightFinish = false;
        movingRight = false;
        xa=0;
        ya=0;
      }
      if(movingUpFinish){
        movingUpFinish = false;
        movingUp = false;
        xa=0;
        ya=0;
      }
      if(movingDownFinish){
        movingDownFinish = false;
        movingDown = false;
        xa=0;
        ya=0;
      }
    }
    
    x= x+xa;
    y= y+ya;
    
  }
  
  
  public void keyPressed(KeyEvent e){
    //only allows movement in one direction at a time
    if (e.getKeyCode() == KeyEvent.VK_A || e.getKeyCode() == KeyEvent.VK_LEFT)
    {
      if(ya == 0){
        xa = -1;
        movingLeft = true;
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_D || e.getKeyCode() == KeyEvent.VK_RIGHT)
    {
      if(ya == 0){
        xa = 1;
        movingRight = true;
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_W || e.getKeyCode() == KeyEvent.VK_UP)
    {
      if(xa ==0){
        ya = -1;
        movingUp = true;
      }
    }
    if (e.getKeyCode() == KeyEvent.VK_S || e.getKeyCode() == KeyEvent.VK_DOWN)
      if(xa == 0){
      ya = 1;
      movingDown = true;
    }
  }
  
  public void keyReleased(KeyEvent e){
    if(xa == -1)
      movingLeftFinish = true;
    if(xa == 1)
      movingRightFinish = true;
    if(ya == 1)
      movingDownFinish = true;
    if(ya == -1)
      movingUpFinish = true;
    
    if(e.getKeyCode() == KeyEvent.VK_SPACE){
      potionOn=true;
    }
    
    xa = 0;
    ya = 0;
  }
  
  public void paint(Graphics g){
    //Paints the actual GraveDigger
    Graphics2D g2 = (Graphics2D) g;
    Image graveDigger = Toolkit.getDefaultToolkit().getImage("GraveDigger.png");
    if (xa == -1) g2.drawImage(graveDigger, x,y-height,width,height, null); //left facing sprite is "default sprite"
    else g2.drawImage(graveDigger, x+width,y-height,-width,height, null); //flipped left sprite
  }
  
  public void collision(Enemy a)  {
    //Method is used when the GraveDigger is colliding with any of the enemies.
    potionCounter++;
    if(!a.getIsDead()){
      int dx = (x-a.x);
      int dy = (y-a.y);  
      if ((int)Math.sqrt(dx*dx+dy*dy)<32)
      {
        if(!potionOn){
          if(!hasArmor)
            isDead = true;
          else
            hasArmor = false;
        }
        
        else if(potionOn && potionCounter <= 200)
        {
          
          a.setIsDead();
        }
        else{
         potionCounter = 0;
         potionOn=false;
        }
      }
      
    }
  }
  
  public void rockCollision(Rock a)  {
    //Method is used when the GraveDigger is colliding with any of the rocks.
    if(level.getTile(xL,yL)=='r' && !a.getRockTouch())
    {
      if(!hasArmor)
        isDead = true;
      else{
        hasArmor = false;
      }
    }  
  }
  
  public void coinCollision(Collectibles2 a) {
    //Allows the GraveDigger to pick up coins if he is colliding with them
    int dx = (x-a.x);
    int dy = (y-a.y);  
    if ((int)Math.sqrt(dx*dx+dy*dy)<32)
    {
      if (a.getIsKey()) {
        hasKey = true;
      }
      if (a.getPickedUp() == false)
      {
        a.setPickedUp();
        coins += 1;
      }
    }
  }
  
  public boolean getDead() {
    return isDead;
  }
  
  public void setDead() {
    isDead = false;
  }
  
  public void setHasArmor(){
    hasArmor = true; 
  }
  
  public boolean getHasArmor(){
    return hasArmor;  
  }
  
  public boolean getHasPotion(){
    return hasPotion; 
  }
  
  public void setHasPotion(){
    hasPotion = true; 
  }
  
  public void setHasKey() {
    hasKey = true;
  }
  
  public boolean levelComplete() {
    return hasKey;
  }
  
  public int getCoins() {
    return coins;
  }
  
  public void setCoins(int a) {
    coins -= a;
  }
} 